<?php
declare(strict_types=1);
require __DIR__.'/config.php';
require __DIR__.'/csrf.php';
require __DIR__.'/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
}

verify_csrf();

$title = trim($_POST['title'] ?? '');
$due = trim($_POST['due_date'] ?? '');
$due = $due !== '' ? $due : null;

if ($title === '') {
    redirect('index.php?err=' . urlencode('Title is required.'));
}

// basic due date validation YYYY-MM-DD
if ($due !== null && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due)) {
    redirect('index.php?err=' . urlencode('Invalid date format.'));
}

$stmt = $pdo->prepare('INSERT INTO tasks (title, due_date) VALUES (:title, :due_date)');
$stmt->execute([':title' => $title, ':due_date' => $due]);

redirect('index.php?ok=' . urlencode('Task added.'));
