<?php
declare(strict_types=1);
require __DIR__.'/config.php';
require __DIR__.'/csrf.php';
require __DIR__.'/functions.php';

// Filter handling
$filter = $_GET['show'] ?? 'all'; // all|active|completed
$valid = ['all','active','completed'];
if (!in_array($filter, $valid, true)) $filter = 'all';

$sql = "SELECT * FROM tasks";
if ($filter === 'active') {
    $sql .= " WHERE is_completed = 0";
} elseif ($filter === 'completed') {
    $sql .= " WHERE is_completed = 1";
}
$sql .= " ORDER BY COALESCE(due_date, '9999-12-31') ASC, created_at DESC";
$stmt = $pdo->query($sql);
$tasks = $stmt->fetchAll();

$flash = $_GET['ok'] ?? '';
$err = $_GET['err'] ?? '';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>To‑Do List (PHP)</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="container">
    <h1>To‑Do List</h1>
    <div class="muted">Add tasks, set a deadline, mark as done ✅</div>

    <?php if ($flash): ?>
      <div class="flash"><?= h($flash) ?></div>
    <?php endif; ?>
    <?php if ($err): ?>
      <div class="error"><?= h($err) ?></div>
    <?php endif; ?>

    <h3>Add Task</h3>
    <form method="post" action="create.php" class="row">
      <?php csrf_field(); ?>
      <input type="text" name="title" placeholder="What do you need to do?" required style="min-width: 260px;">
      <input type="date" name="due_date">
      <button class="btn primary" type="submit">Add</button>
    </form>

    <div class="row" style="justify-content: space-between;">
      <div class="filters">
        <span class="badge">Filter:</span>
        <a href="?show=all">All</a>
        <a href="?show=active">Active</a>
        <a href="?show=completed">Completed</a>
      </div>
      <div class="muted">
        <?= count($tasks) ?> task(s) shown
      </div>
    </div>

    <div class="list">
    <?php foreach ($tasks as $t): ?>
      <div class="task <?= $t['is_completed'] ? 'done' : '' ?>">
        <form method="post" action="toggle.php">
          <?php csrf_field(); ?>
          <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
          <button class="btn" type="submit" title="Toggle done"><?= $t['is_completed'] ? '☑' : '☐' ?></button>
        </form>
        <div class="title">
          <strong><?= h($t['title']) ?></strong><br>
          <span class="muted">Created: <?= h($t['created_at']) ?></span>
        </div>
        <div>
          <?php if ($t['due_date']): ?>
            <span class="badge">Due: <?= h($t['due_date']) ?></span>
          <?php else: ?>
            <span class="badge">No deadline</span>
          <?php endif; ?>
        </div>
        <div class="row">
          <form method="get" action="edit.php">
            <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
            <button class="btn" type="submit">Edit</button>
          </form>
          <form method="post" action="delete.php" onsubmit="return confirm('Delete this task?');">
            <?php csrf_field(); ?>
            <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
            <button class="btn danger" type="submit">Delete</button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
    </div>
  </div>
</body>
</html>
