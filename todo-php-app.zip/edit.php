<?php
declare(strict_types=1);
require __DIR__.'/config.php';
require __DIR__.'/csrf.php';
require __DIR__.'/functions.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { redirect('index.php'); }

$stmt = $pdo->prepare('SELECT * FROM tasks WHERE id = :id');
$stmt->execute([':id' => $id]);
$task = $stmt->fetch();
if (!$task) { redirect('index.php?err=' . urlencode('Task not found.')); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Edit Task</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="container">
    <h1>Edit Task</h1>
    <form method="post" action="update.php" class="row">
      <?php csrf_field(); ?>
      <input type="hidden" name="id" value="<?= (int)$task['id'] ?>">
      <input type="text" name="title" value="<?= h($task['title']) ?>" required style="min-width: 260px;">
      <input type="date" name="due_date" value="<?= h((string)$task['due_date']) ?>">
      <button class="btn primary" type="submit">Save</button>
      <a class="btn" href="index.php">Cancel</a>
    </form>
  </div>
</body>
</html>
