<?php
declare(strict_types=1);
require __DIR__.'/config.php';
require __DIR__.'/csrf.php';
require __DIR__.'/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
}
verify_csrf();

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) redirect('index.php?err=' . urlencode('Invalid task id.'));

$pdo->beginTransaction();
try {
    $row = $pdo->prepare('SELECT is_completed FROM tasks WHERE id = :id FOR UPDATE');
    $row->execute([':id' => $id]);
    $current = $row->fetch();
    if (!$current) {
        $pdo->rollBack();
        redirect('index.php?err=' . urlencode('Task not found.'));
    }
    $new = $current['is_completed'] ? 0 : 1;
    $upd = $pdo->prepare('UPDATE tasks SET is_completed = :new WHERE id = :id');
    $upd->execute([':new' => $new, ':id' => $id]);
    $pdo->commit();
    redirect('index.php?ok=' . urlencode('Task updated.'));
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    redirect('index.php?err=' . urlencode('Failed to update.'));
}
