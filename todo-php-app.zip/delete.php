<?php
declare(strict_types=1);
require __DIR__.'/config.php';
require __DIR__.'/csrf.php';
require __DIR__.'/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
}
verify_csrf();

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) redirect('index.php?err=' . urlencode('Invalid task id.'));

$stmt = $pdo->prepare('DELETE FROM tasks WHERE id = :id');
$stmt->execute([':id' => $id]);

redirect('index.php?ok=' . urlencode('Task deleted.'));
